import 'package:flutter/material.dart';

void main() {
  runApp(const WaterTrackerApp());
}

class WaterTrackerApp extends StatelessWidget {
  const WaterTrackerApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Water Intake Tracker',
      theme: ThemeData(primarySwatch: Colors.blue),
      home: const WaterTrackerScreen(),
      debugShowCheckedModeBanner: false,
    );
  }
}

class WaterTrackerScreen extends StatefulWidget {
  const WaterTrackerScreen({super.key});

  @override
  State<WaterTrackerScreen> createState() => _WaterTrackerScreenState();
}

class _WaterTrackerScreenState extends State<WaterTrackerScreen> {
  final int dailyGoal = 2000; // 2000 mL goal
  final List<int> entries = [];
  final TextEditingController _controller = TextEditingController();
  final _formKey = GlobalKey<FormState>();

  int get totalConsumed => entries.fold(0, (sum, element) => sum + element);
  int get remainingWater => (dailyGoal - totalConsumed).clamp(0, dailyGoal);
  double get completionPercentage =>
      ((totalConsumed / dailyGoal) * 100).clamp(0.0, 100.0);

  void _addWater() {
    if (_formKey.currentState!.validate()) {
      int enteredValue = int.parse(_controller.text);
      setState(() {
        entries.add(enteredValue);
        _controller.clear();
      });
    }
  }

  void _confirmReset() {
    showDialog(
      context: context,
      builder: (BuildContext context) {
        return AlertDialog(
          title: const Text('Reset Intake'),
          content: const Text(
              'Are you sure you want to reset today\'s water intake?'),
          actions: [
            TextButton(
              child: const Text('Cancel'),
              onPressed: () => Navigator.of(context).pop(),
            ),
            TextButton(
              child: const Text('Reset', style: TextStyle(color: Colors.red)),
              onPressed: () {
                setState(() {
                  entries.clear();
                });
                Navigator.of(context).pop();
              },
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: const Text('Smart Water Tracker'),
        actions: [
          IconButton(
            icon: const Icon(Icons.refresh),
            onPressed: _confirmReset,
            tooltip: 'Reset Intake',
          ),
        ],
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Column(
          children: [
            // Progress Section
            Card(
              elevation: 4,
              child: Padding(
                padding: const EdgeInsets.all(16.0),
                child: Column(
                  children: [
                    Text('Daily Goal: $dailyGoal mL',
                        style: const TextStyle(
                            fontSize: 18, fontWeight: FontWeight.bold)),
                    const SizedBox(height: 10),
                    LinearProgressIndicator(
                      value: totalConsumed / dailyGoal,
                      minHeight: 10,
                      backgroundColor: Colors.grey[300],
                      valueColor:
                          const AlwaysStoppedAnimation<Color>(Colors.blue),
                    ),
                    const SizedBox(height: 15),
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceAround,
                      children: [
                        _infoColumn('Consumed', '$totalConsumed mL'),
                        _infoColumn('Remaining', '$remainingWater mL'),
                        _infoColumn('Entries', '${entries.length}'),
                        _infoColumn('Progress',
                            '${completionPercentage.toStringAsFixed(0)}%'),
                      ],
                    ),
                  ],
                ),
              ),
            ),
            const SizedBox(height: 20),
            // Input Form Section
            Form(
              key: _formKey,
              child: Row(
                children: [
                  Expanded(
                    child: TextFormField(
                      controller: _controller,
                      keyboardType: TextInputType.number,
                      decoration: const InputDecoration(
                        labelText: 'Enter water (mL)',
                        border: OutlineInputBorder(),
                      ),
                      validator: (value) {
                        if (value == null || value.isEmpty) {
                          return 'Please enter a value';
                        }
                        int? val = int.tryParse(value);
                        if (val == null || val <= 0) {
                          return 'Enter a value greater than 0';
                        }
                        return null;
                      },
                    ),
                  ),
                  const SizedBox(width: 10),
                  ElevatedButton(
                    onPressed: _addWater,
                    style: ElevatedButton.styleFrom(
                        padding: const EdgeInsets.all(16)),
                    child: const Text('Add'),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            const Text('Today\'s Entries',
                style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
            const Divider(),
            // Entries List
            Expanded(
              child: entries.isEmpty
                  ? const Center(
                      child: Text('No water intake recorded yet today.'))
                  : ListView.builder(
                      itemCount: entries.length,
                      itemBuilder: (context, index) {
                        return ListTile(
                          leading:
                              const Icon(Icons.local_drink, color: Colors.blue),
                          title: Text('Entry ${index + 1}'),
                          trailing: Text('${entries[index]} mL',
                              style:
                                  const TextStyle(fontWeight: FontWeight.bold)),
                        );
                      },
                    ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _infoColumn(String label, String value) {
    return Column(
      children: [
        Text(label, style: const TextStyle(color: Colors.grey, fontSize: 12)),
        const SizedBox(height: 4),
        Text(value,
            style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 14)),
      ],
    );
  }
}
